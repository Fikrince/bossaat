# BOŞSAAT — MVP başlangıç paketi

Bu paket, BOŞSAAT için geliştirilebilir bir Next.js + Supabase MVP iskeletidir.

## İçindekiler
- Mobil uyumlu ana sayfa, arama ve kategori/ilçe filtreleri
- Örnek fırsat kartları (gerçek işletme veya gerçek fiyat değildir)
- E-posta/şifre kayıt ve giriş ekranları (Supabase Auth)
- Müşteri paneli ve rezervasyon geçmişi
- İşletme başvuru formu (başvurular yönetici onayına düşer)
- İşletme paneli: fırsat oluşturma, fırsat listesi ve rezervasyon taleplerini onaylama/reddetme
- Yönetici başvuru ekranı (profil rolü admin yapılınca)
- Supabase tabloları ve temel Row Level Security politikaları
- Vercel yayın rehberi

## Yerel kurulum
1. Node.js 20+ kurun.
2. Terminalde proje klasöründe `npm install` çalıştırın.
3. `.env.example` dosyasını `.env.local` olarak kopyalayın.
4. Supabase projesi açın. Project URL ve anon/public key değerlerini `.env.local` dosyasına girin.
5. Supabase SQL Editor'da `supabase/schema.sql` dosyasını çalıştırın.
6. Supabase Authentication > URL Configuration bölümünde yerel geliştirme adresini (`http://localhost:3000`) ekleyin.
7. `npm run dev` çalıştırın.

## Vercel
1. Projeyi GitHub deposuna yükleyin.
2. Vercel'de New Project > GitHub deposunu içe aktarın.
3. `NEXT_PUBLIC_SUPABASE_URL` ve `NEXT_PUBLIC_SUPABASE_ANON_KEY` ortam değişkenlerini tanımlayın.
4. Deploy edin.
5. Supabase Auth URL Configuration içine gerçek Vercel alan adını ekleyin.

## Yönetici hesabı
İlk kullanıcıyı normal kayıt ekranından oluşturun. Supabase > Authentication > Users içinden kullanıcının UUID değerini kopyalayın. SQL Editor'da şu komutu kendi UUID'nizle çalıştırın:
`update public.profiles set role='admin' where id='AUTH_USER_UUID';`
Ardından `/yonetim` sayfasına gidin.

## Önemli: henüz üretime hazır değil
- Gerçek ödeme/komisyon yoktur.
- İşletme panelinde teklif oluşturma ve düzenleme ekranı henüz tamamlanmadı.
- Rezervasyon saat çakışması/kapasite kontrolü ve otomatik bildirimler eklenmelidir.
- Yönetici yetkileri için daha kapsamlı güvenlik denetimi yapılmalıdır.
- KVKK, açık rıza gereken alanlar, gizlilik politikası, kullanım koşulları, mesafeli sözleşme ve iptal/iade süreçleri hukuk ve ödeme sağlayıcısı şartlarına göre hazırlanmalıdır.
- Ödeme sağlayıcısı seçimi ve pazar yeri/alt üye işyeri modeli Türkiye mevzuatı ve sağlayıcı şartları doğrulanarak yapılmalıdır.
- Demo fırsatları yayından önce gerçek, izinli işletme verileriyle değiştirilmeli; örnek kayıtlar kaldırılmalıdır.

Bu paket canlı, tamamlanmış bir pazar yeri değildir. Supabase ve Vercel bağlantısı, gerçek işletmeler, testler ve operasyonel kontroller tamamlanmadan kullanıma açılmamalıdır.
