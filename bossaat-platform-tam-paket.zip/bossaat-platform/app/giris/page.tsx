"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase, supabaseReady } from "@/lib/supabase";

export default function LoginPage() {
  const router = useRouter();
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);

  async function submit(e:React.FormEvent) {
    e.preventDefault();
    if(!supabaseReady || !supabase){setMessage("Önce Supabase bağlantısını kurmalısınız. Kurulum rehberine bakın.");return;}
    setBusy(true); setMessage("");
    const {error}=await supabase.auth.signInWithPassword({email,password});
    setBusy(false);
    if(error){setMessage("Giriş yapılamadı. E-posta ve şifrenizi kontrol edin.");return;}
    router.push("/panel");
  }
  return <main className="auth-shell"><section className="auth-card"><Link className="brand auth-brand" href="/"><span className="brand-mark">B</span><span>BOŞSAAT<small>YEREL FIRSAT AĞI</small></span></Link><span className="eyebrow dark">TEKRAR HOŞ GELDİN</span><h1>Hesabına giriş yap.</h1><p>Fırsatlarını ve rezervasyonlarını tek yerden yönet.</p><form onSubmit={submit}><label>E-posta<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="ornek@mail.com"/></label><label>Şifre<input type="password" required minLength={6} value={password} onChange={e=>setPassword(e.target.value)} placeholder="Şifren"/></label><button className="submit-btn" disabled={busy}>{busy?"Giriş yapılıyor…":"Giriş yap"}</button></form>{message&&<div className="auth-message">{message}</div>}<div className="auth-switch">Hesabın yok mu? <Link href="/kayit">Ücretsiz kayıt ol</Link></div><Link className="back-link" href="/">← Ana sayfaya dön</Link></section></main>;
}
