
"use client";
import {useEffect,useState} from "react";
import Link from "next/link";
import {useRouter} from "next/navigation";
import {supabase} from "@/lib/supabase";

export default function BusinessPanel(){
 const router=useRouter();const [business,setBusiness]=useState<any>(null);const [offers,setOffers]=useState<any[]>([]);const [requests,setRequests]=useState<any[]>([]);const [title,setTitle]=useState("");const [category,setCategory]=useState("Berber");const [description,setDescription]=useState("");const [start,setStart]=useState("");const [oldPrice,setOldPrice]=useState("");const [price,setPrice]=useState("");const [msg,setMsg]=useState("Yükleniyor…");
 async function load(){
  if(!supabase)return;
  const {data:{user}}=await supabase.auth.getUser();if(!user){router.replace("/giris");return;}
  const {data:b}=await supabase.from("businesses").select("*").eq("owner_id",user.id).order("created_at",{ascending:false}).limit(1).maybeSingle();
  if(!b){setMsg("Henüz işletme başvurunuz yok. Önce ücretsiz başvuru yapın.");return;}
  setBusiness(b);
  const {data:o}=await supabase.from("offers").select("*").eq("business_id",b.id).order("created_at",{ascending:false});setOffers(o||[]);
  const {data:r}=await supabase.from("reservations").select("id,status,customer_name,customer_phone,created_at,offers!inner(title,business_id)").eq("offers.business_id",b.id).order("created_at",{ascending:false});setRequests(r||[]);
  setMsg(b.status==="approved"?"İşletmeniz onaylandı. Fırsat ekleyebilirsiniz.":`İşletme başvurunuz: ${b.status==="pending"?"Onay bekliyor":b.status}. Onaylanana kadar fırsatlar yayınlanmaz.`);
 }
 useEffect(()=>{load()},[]);
 async function addOffer(e:React.FormEvent){
  e.preventDefault();if(!supabase||!business)return;
  if(business.status!=="approved"){setMsg("Fırsat yayınlamak için işletme başvurunuzun onaylanması gerekiyor.");return;}
  const a=Number(oldPrice),b=Number(price);if(!a||!b||b>a){setMsg("İndirimli fiyat, normal fiyattan yüksek olamaz.");return;}
  const {error}=await supabase.from("offers").insert({business_id:business.id,title,category,district:business.district,description,starts_at:new Date(start).toISOString(),original_price:a,offer_price:b,status:"published"});
  setMsg(error?"Fırsat eklenemedi. Tarih ve fiyat bilgilerini kontrol edin.":"Fırsat eklendi.");if(!error){setTitle("");setDescription("");setStart("");setOldPrice("");setPrice("");load();}
 }
 async function setStatus(id:string,status:string){if(!supabase)return;const {error}=await supabase.from("reservations").update({status}).eq("id",id);setMsg(error?"Rezervasyon güncellenemedi.":"Rezervasyon durumu güncellendi.");load();}
 return <main className="dashboard"><header className="dash-nav"><Link className="brand" href="/"><span className="brand-mark">B</span><span>BOŞSAAT<small>İŞLETME PANELİ</small></span></Link><Link href="/panel">Müşteri paneli</Link></header><section className="dash-content"><span className="eyebrow dark">İŞLETME YÖNETİMİ</span><h1>{business?.name||"İşletme paneli"}</h1><p>{msg}</p>{business&&<><div className="status-strip">Başvuru durumu: <b>{business.status==="approved"?"Onaylandı":business.status==="pending"?"Onay bekliyor":business.status}</b></div><h2>Yeni fırsat oluştur</h2><form className="offer-form" onSubmit={addOffer}><label>Fırsat başlığı<input required value={title} onChange={e=>setTitle(e.target.value)} placeholder="Örn. Bugün 15.00 saç kesimi"/></label><label>Kategori<select value={category} onChange={e=>setCategory(e.target.value)}>{["Berber","Kuaför","Oto yıkama","Kafe","Güzellik","Spor","Diğer"].map(x=><option key={x}>{x}</option>)}</select></label><label>Başlangıç zamanı<input type="datetime-local" required value={start} onChange={e=>setStart(e.target.value)}/></label><label>Normal fiyat (₺)<input type="number" min="0" required value={oldPrice} onChange={e=>setOldPrice(e.target.value)}/></label><label>Fırsat fiyatı (₺)<input type="number" min="0" required value={price} onChange={e=>setPrice(e.target.value)}/></label><label>Açıklama<textarea rows={2} value={description} onChange={e=>setDescription(e.target.value)}/></label><button className="submit-btn" disabled={business.status!=="approved"}>Fırsatı yayınla</button></form><h2>Fırsatlarım</h2>{offers.length?offers.map(o=><div className="admin-row" key={o.id}><div><b>{o.title}</b><span>{o.offer_price} ₺ · {o.status}</span></div></div>):<div className="empty">Henüz fırsat eklemediniz.</div>}<h2>Rezervasyon talepleri</h2>{requests.length?requests.map(r=><div className="admin-row" key={r.id}><div><b>{r.customer_name} · {r.offers?.title}</b><span>{r.customer_phone} · {r.status}</span></div><div className="admin-actions"><button onClick={()=>setStatus(r.id,"approved")}>Onayla</button><button onClick={()=>setStatus(r.id,"rejected")}>Reddet</button></div></div>):<div className="empty">Henüz rezervasyon talebi yok.</div>}</>}</section></main>;
}
