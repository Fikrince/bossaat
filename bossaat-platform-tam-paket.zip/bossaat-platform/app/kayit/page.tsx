"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase, supabaseReady } from "@/lib/supabase";

export default function SignupPage() {
  const router=useRouter();
  const [name,setName]=useState(""); const [email,setEmail]=useState("");
  const [phone,setPhone]=useState(""); const [password,setPassword]=useState("");
  const [message,setMessage]=useState(""); const [busy,setBusy]=useState(false);
  async function submit(e:React.FormEvent){
    e.preventDefault();
    if(!supabaseReady||!supabase){setMessage("Önce Supabase bağlantısını kurmalısınız.");return;}
    setBusy(true);setMessage("");
    const {data,error}=await supabase.auth.signUp({email,password,options:{data:{full_name:name,phone}}});
    setBusy(false);
    if(error){setMessage("Kayıt oluşturulamadı: "+error.message);return;}
    if(data.session) router.push("/panel");
    else setMessage("Kayıt alındı. E-posta doğrulama bağlantısını kontrol edin; ardından giriş yapabilirsiniz.");
  }
  return <main className="auth-shell"><section className="auth-card"><Link className="brand auth-brand" href="/"><span className="brand-mark">B</span><span>BOŞSAAT<small>YEREL FIRSAT AĞI</small></span></Link><span className="eyebrow dark">ÜCRETSİZ ÜYELİK</span><h1>Fırsatlara yer aç.</h1><p>Hesabını oluştur, yakındaki fırsatları takip et.</p><form onSubmit={submit}><label>Ad soyad<input required value={name} onChange={e=>setName(e.target.value)} placeholder="Adın soyadın"/></label><label>E-posta<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="ornek@mail.com"/></label><label>Telefon<input type="tel" required value={phone} onChange={e=>setPhone(e.target.value)} placeholder="05xx xxx xx xx"/></label><label>Şifre<input type="password" required minLength={8} value={password} onChange={e=>setPassword(e.target.value)} placeholder="En az 8 karakter"/></label><button className="submit-btn" disabled={busy}>{busy?"Hesap oluşturuluyor…":"Ücretsiz hesap oluştur"}</button></form>{message&&<div className="auth-message">{message}</div>}<div className="auth-switch">Zaten hesabın var mı? <Link href="/giris">Giriş yap</Link></div><Link className="back-link" href="/">← Ana sayfaya dön</Link></section></main>;
}
