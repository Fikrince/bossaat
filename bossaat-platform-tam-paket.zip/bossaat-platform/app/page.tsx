"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { ArrowUpRight, Clock3, MapPin, Search, ShieldCheck, Sparkles, Store, Tag } from "lucide-react";
import { supabase, supabaseReady } from "@/lib/supabase";

type Offer = {
  id: string; title: string; business_name: string; category: string;
  district: string; starts_at: string; original_price: number; offer_price: number;
  image_url: string; description: string;
};

const demoOffers: Offer[] = [
  { id:"demo-1", title:"Saç kesiminde fırsat", business_name:"Örnek Berber", category:"Berber", district:"Torbalı", starts_at:"Bugün 14:30", original_price:400, offer_price:280, image_url:"https://images.unsplash.com/photo-1509710887729-6d4c7c1f4c0f?auto=format&fit=crop&w=1000&q=85", description:"Boş kalan randevu saatine özel indirim." },
  { id:"demo-2", title:"Detaylı oto yıkama", business_name:"Örnek Oto Bakım", category:"Oto yıkama", district:"Ayrancılar", starts_at:"Bugün 16:00", original_price:900, offer_price:650, image_url:"https://images.unsplash.com/photo-1607860108855-64acf2078ed9?auto=format&fit=crop&w=1000&q=85", description:"Bugünkü boş saat için avantajlı fiyat." },
  { id:"demo-3", title:"Fön ve bakım", business_name:"Örnek Güzellik Stüdyosu", category:"Kuaför", district:"Torbalı", starts_at:"Yarın 11:00", original_price:600, offer_price:420, image_url:"https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=1000&q=85", description:"Sınırlı saat için özel teklif." },
  { id:"demo-4", title:"Kahve ve tatlı ikilisi", business_name:"Örnek Kahve Evi", category:"Kafe", district:"Ayrancılar", starts_at:"Bugün 17:30", original_price:250, offer_price:185, image_url:"https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1000&q=85", description:"Günün sakin saatlerine özel." }
];

const categories = ["Tümü", "Berber", "Kuaför", "Oto yıkama", "Kafe", "Güzellik", "Spor"];

export default function Home() {
  const [category, setCategory] = useState("Tümü");
  const [district, setDistrict] = useState("Tümü");
  const [query, setQuery] = useState("");
  const [offers, setOffers] = useState<Offer[]>(demoOffers);
  const [selected, setSelected] = useState<Offer | null>(null);
  const [notice, setNotice] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [phone, setPhone] = useState("");

  const filtered = useMemo(() => offers.filter(o =>
    (category === "Tümü" || o.category === category) &&
    (district === "Tümü" || o.district === district) &&
    `${o.title} ${o.business_name} ${o.category}`.toLocaleLowerCase("tr").includes(query.toLocaleLowerCase("tr"))
  ), [offers, category, district, query]);

  async function loadLiveOffers() {
    if (!supabase) return;
    const { data, error } = await supabase.from("offers").select("id,title,category,district,starts_at,original_price,offer_price,image_url,description,businesses(name)").eq("status","published").order("starts_at");
    if (error) { setNotice("Canlı fırsatlar yüklenemedi. Supabase tablolarını kurduğunuzdan emin olun."); return; }
    if (data?.length) {
      setOffers(data.map((x: any) => ({
        id:x.id, title:x.title, business_name:x.businesses?.name ?? "İşletme",
        category:x.category, district:x.district, starts_at:new Date(x.starts_at).toLocaleString("tr-TR"),
        original_price:x.original_price, offer_price:x.offer_price,
        image_url:x.image_url || demoOffers[0].image_url, description:x.description || ""
      })));
    }
  }

  async function reserve() {
    if (!customerName.trim() || !phone.trim()) { setNotice("Rezervasyon talebi için adınızı ve telefonunuzu yazın."); return; }
    if (!supabase || selected?.id.startsWith("demo-")) {
      setNotice("Bu örnek fırsat demosudur. Gerçek rezervasyon için işletme ve veritabanı kurulumu gerekiyor.");
      return;
    }
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setNotice("Rezervasyon için önce ücretsiz hesap açıp giriş yapmalısınız."); return; }
    const { error } = await supabase.from("reservations").insert({
      offer_id: selected.id, customer_id: user.id, customer_name: customerName.trim(), customer_phone: phone.trim(), status:"pending"
    });
    setNotice(error ? "Talep gönderilemedi. Bilgileri kontrol edip tekrar deneyin." : "Rezervasyon talebiniz işletmeye iletildi.");
    if (!error) setSelected(null);
  }

  return (
    <main>
      <nav className="nav wrap">
        <a className="brand" href="#"><span className="brand-mark">B</span><span>BOŞSAAT<small>YEREL FIRSAT AĞI</small></span></a>
        <div className="nav-links"><a href="#nasil">Nasıl çalışır?</a><a href="#isletme">İşletmeler için</a><Link href="/giris">Giriş yap</Link></div>
        <a className="nav-cta" href="/kayit">Ücretsiz katıl <ArrowUpRight size={16}/></a>
      </nav>

      <section className="hero">
        <div className="hero-grid"></div>
        <div className="wrap hero-inner">
          <div className="eyebrow"><span></span> YAKININDAKİ BOŞ SAATLERİ KEŞFET</div>
          <h1>Boş kalan saatler,<br/><em>senin fırsatın.</em></h1>
          <p className="hero-copy">Yakınındaki işletmelerin boş randevu saatlerini keşfet. Aynı hizmete daha avantajlı fiyatla ulaş.</p>
          <a className="hero-button" href="#firsatlar">Fırsatları keşfet <ArrowUpRight size={18}/></a>
          <div className="hero-foot"><span><ShieldCheck size={15}/> Şeffaf fırsatlar</span><span><Clock3 size={15}/> Son dakika avantajları</span></div>
        </div>
        <div className="hero-orbit orbit-one"></div><div className="hero-orbit orbit-two"></div>
      </section>

      <section className="wrap search-panel" id="firsatlar">
        <div className="search-heading"><div><span className="eyebrow dark">BUGÜNÜN FIRSATLARI</span><h2>Boş saatini yakala.</h2></div><span className="live-label"><i></i> {supabaseReady ? "Platform bağlantısı hazır" : "Örnek gösterim"}</span></div>
        <div className="filters">
          <label className="search-input"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Hizmet veya işletme ara"/></label>
          <select value={district} onChange={e=>setDistrict(e.target.value)} aria-label="Bölge"><option value="Tümü">Tüm bölgeler</option><option>Torbalı</option><option>Ayrancılar</option></select>
        </div>
        <div className="chips">{categories.map(c=><button key={c} className={category===c?"chip active":"chip"} onClick={()=>setCategory(c)}>{c}</button>)}</div>
        <div className="offer-grid">
          {filtered.map(o=><article className="offer-card" key={o.id}>
            <div className="offer-photo" style={{backgroundImage:`url("${o.image_url}")`}}><span className="offer-tag"><Tag size={13}/>{o.category}</span><span className="save-tag">Son saat fırsatı</span></div>
            <div className="offer-body"><div className="offer-top"><span className="business">{o.business_name}</span><span className="district"><MapPin size={13}/>{o.district}</span></div><h3>{o.title}</h3><p>{o.description}</p><div className="offer-bottom"><div><strong>{o.offer_price.toLocaleString("tr-TR")} ₺</strong><del>{o.original_price.toLocaleString("tr-TR")} ₺</del></div><button onClick={()=>{setSelected(o);setNotice("");}} className="detail-btn">İncele <ArrowUpRight size={15}/></button></div><div className="time-row"><Clock3 size={14}/>{o.starts_at}</div></div>
          </article>)}
        </div>
        {filtered.length===0 && <div className="empty">Aramana uygun fırsat bulunamadı. Filtreleri değiştirmeyi dene.</div>}
        <p className="demo-note">Not: Şu an görünen işletme ve fiyatlar örnek amaçlıdır; gerçek ilan değildir.</p>
      </section>

      <section className="how wrap" id="nasil"><div className="section-kicker">BASİT. HIZLI. AVANTAJLI.</div><h2>Üç adımda fırsat senin.</h2><div className="steps"><div><b>01</b><Sparkles/><h3>Keşfet</h3><p>Yakınındaki hizmetleri ve uygun saatleri görüntüle.</p></div><div><b>02</b><Clock3/><h3>Talep gönder</h3><p>Sana uyan saat için rezervasyon isteği oluştur.</p></div><div><b>03</b><ShieldCheck/><h3>Onayını al</h3><p>İşletme onayladığında fırsatını değerlendir.</p></div></div></section>

      <section className="business-band" id="isletme"><div className="wrap business-inner"><div><span className="eyebrow">İŞLETMELER İÇİN</span><h2>Boş saatini gelire dönüştür.</h2><p>Randevu defterindeki boşlukları yeni müşterilerle doldur. İlk katılım dönemi ücretsiz olacak.</p></div><a href="/isletme-kayit" className="business-button">İşletmeni ücretsiz ekle <ArrowUpRight size={17}/></a></div></section>
      <footer className="footer"><div className="wrap footer-inner"><a className="brand" href="#"><span className="brand-mark">B</span><span>BOŞSAAT<small>YEREL FIRSAT AĞI</small></span></a><span>© 2026 BOŞSAAT. Tüm hakları saklıdır.</span><a href="mailto:merhaba@bossaat.com">İletişim</a></div></footer>

      {selected && <div className="modal-backdrop" onClick={()=>setSelected(null)}><section className="modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setSelected(null)}>×</button><span className="eyebrow dark">REZERVASYON TALEBİ</span><h2>{selected.title}</h2><p>{selected.business_name} · {selected.district} · {selected.starts_at}</p><div className="modal-price">{selected.offer_price.toLocaleString("tr-TR")} ₺ <del>{selected.original_price.toLocaleString("tr-TR")} ₺</del></div><label>Adınız<input value={customerName} onChange={e=>setCustomerName(e.target.value)} placeholder="Ad soyad"/></label><label>Telefon numaranız<input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="05xx xxx xx xx"/></label><button className="submit-btn" onClick={reserve}>Rezervasyon talebi gönder</button>{notice && <p className="notice">{notice}</p>}</section></div>}
      {notice && !selected && <div className="toast" onClick={()=>setNotice("")}>{notice}</div>}
    </main>
  );
}
