"use client";
import {useEffect,useState} from "react";
import Link from "next/link";
import {useRouter} from "next/navigation";
import {supabase} from "@/lib/supabase";

export default function AdminPage(){
 const router=useRouter();const [items,setItems]=useState<any[]>([]);const [msg,setMsg]=useState("Yönetici hesabı ile giriş yapın.");const [ready,setReady]=useState(false);
 async function load(){if(!supabase)return;const {data:{user}}=await supabase.auth.getUser();if(!user){router.replace("/giris");return;}const {data:profile}=await supabase.from("profiles").select("role").eq("id",user.id).single();if(profile?.role!=="admin"){setMsg("Bu sayfa yalnızca yönetici yetkisine sahip hesaplara açıktır.");setReady(true);return;}const {data,error}=await supabase.from("businesses").select("*").eq("status","pending").order("created_at");setItems(data||[]);setMsg(error?"Başvurular yüklenemedi.":`${(data||[]).length} onay bekleyen işletme başvurusu.`);setReady(true)}
 useEffect(()=>{load()},[]);
 async function decide(id:string,status:"approved"|"rejected"){if(!supabase)return;const {error}=await supabase.from("businesses").update({status}).eq("id",id);setMsg(error?"İşlem başarısız.":"Başvuru durumu güncellendi.");load()}
 return <main className="dashboard"><header className="dash-nav"><Link className="brand" href="/"><span className="brand-mark">B</span><span>BOŞSAAT<small>YÖNETİM</small></span></Link><Link href="/panel">Hesabım</Link></header><section className="dash-content"><span className="eyebrow dark">YÖNETİM PANELİ</span><h1>İşletme başvuruları</h1><p>{msg}</p>{ready&&items.map(x=><article className="admin-row" key={x.id}><div><b>{x.name}</b><span>{x.category} · {x.district} · {x.phone}</span><small>{x.address}</small></div><div className="admin-actions"><button onClick={()=>decide(x.id,"approved")}>Onayla</button><button onClick={()=>decide(x.id,"rejected")}>Reddet</button></div></article>)}</section></main>;
}
